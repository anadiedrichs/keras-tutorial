library(tfruns)
training_run("mnist_mlp.R")
